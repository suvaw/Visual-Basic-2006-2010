﻿Public Class Form1
    Private Access As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub Form1_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        ' RUN QUERY
        Access.ExecQuery("SELECT * FROM Members ORDER BY username ASC")
        If NotEmpty(Access.Exception) Then MsgBox(Access.Exception) : Exit Sub

        ' FILL DATAGRID
        dgvData.DataSource = Access.DBDT

        ' FILL COMBOBOX
        For Each R As DataRow In Access.DBDT.Rows
            cbxUsers.Items.Add(R("username"))
        Next

        ' DISPLAY FIRS NAME FOUND
        If Access.RecordCount > 0 Then cbxUsers.SelectedIndex = 0
    End Sub

    Private Sub SearchMember(Name As String)
        ' ADD PARAMETERS & RUN QUERY
        Access.AddParam("@user", "%" & Name & "%")
        Access.ExecQuery("SELECT username, password, email " & _
                         "FROM members " & _
                         "WHERE username LIKE @user")

        ' REPORT & ABORT ON ERRORS
        If NotEmpty(Access.Exception) Then MsgBox(Access.Exception) : Exit Sub

        ' FILL DATAGRIDVIEW
        dgvData.DataSource = Access.DBDT
    End Sub

    Private Sub cmdFind_Click(sender As System.Object, e As System.EventArgs) Handles cmdFind.Click
        SearchMember(txtFind.Text)
    End Sub
End Class
