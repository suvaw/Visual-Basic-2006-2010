﻿Public Class Form1
    Private Access As New DBControl

    Private Function NoErrors(Optional Report As Boolean = False) As Boolean
        If Not String.IsNullOrEmpty(Access.Exception) Then
            If Report = True Then MsgBox(Access.Exception) ' REPORT ERRORS
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub Form1_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        RefreshGrid()
    End Sub

    Public Sub RefreshGrid()
        ' RUN QUERY
        Access.ExecQuery("SELECT * FROM Members ORDER BY username ASC")

        ' REPORT & ABORT ON ERRORS
        If NoErrors(True) = False Then Exit Sub

        ' FILL DATAGRID
        dgvData.DataSource = Access.DBDT

        ' CLEAR COMBOBOX
        cbxUsers.Items.Clear()

        ' FILL COMBOBOX
        For Each R As DataRow In Access.DBDT.Rows
            cbxUsers.Items.Add(R("username"))
        Next

        ' DISPLAY FIRS NAME FOUND
        If Access.RecordCount > 0 Then cbxUsers.SelectedIndex = 0
    End Sub

    Private Sub SearchMember(Name As String)
        ' ADD PARAMETERS & RUN QUERY
        Access.AddParam("@user", "%" & Name & "%")
        Access.ExecQuery("SELECT username, password, email " & _
                         "FROM members " & _
                         "WHERE username LIKE @user")

        ' REPORT & ABORT ON ERRORS
        If NoErrors(True) = False Then Exit Sub

        ' FILL DATAGRIDVIEW
        dgvData.DataSource = Access.DBDT
    End Sub

    Private Sub DeleteUser()
        ' CONFIRM DELETE
        If MsgBox("Are you sure that you want to delete the selected user?", MsgBoxStyle.YesNo, "Confirm Delete") = MsgBoxResult.No Then Exit Sub

        ' DELETE SELECTED USER
        Access.AddParam("@uid", txtDelID.Text)
        Access.ExecQuery("DELETE FROM members WHERE id=@uid")

        ' REPORT & ABORT ON ERRORS
        If NoErrors(True) = False Then Exit Sub

        ' CLEANUP & REFRESH
        txtDelID.Clear()
        txtDelUser.Clear()
        msiDeleteUser.Enabled = False
        RefreshGrid()
    End Sub

    Private Sub SelectUser(Username As String)
        ' QUERY USER
        Access.AddParam("@user", Username)
        Access.ExecQuery("SELECT TOP 1 id, username FROM members WHERE username=@user ")

        ' REPORT & ABORT ON ERRORS OR NO RECORDS FOUND
        If NoErrors(True) = False OrElse Access.RecordCount < 1 Then Exit Sub

        ' GET FIRST ROW FOUND
        Dim r As DataRow = Access.DBDT.Rows(0)

        ' POPULATE TEXTBOXES WITH DATA
        txtDelID.Text = r("ID").ToString
        txtDelUser.Text = r("username").ToString

        ' ENABLE DELETE
        msiDeleteUser.Enabled = True
    End Sub

    Private Sub cmdFind_Click(sender As System.Object, e As System.EventArgs) Handles cmdFind.Click
        SearchMember(txtFind.Text)
    End Sub

    Private Sub NewUserToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles NewUserToolStripMenuItem.Click
        NewUser.Show()
    End Sub

    Private Sub cbxUsers_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbxUsers.SelectedIndexChanged
        If Not String.IsNullOrEmpty(cbxUsers.Text) Then SelectUser(cbxUsers.Text)
    End Sub

    Private Sub dgvData_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvData.CellClick
        ' PREVENT OUT OF INDEX RANGE ERRORS
        If e.RowIndex < 0 Or e.ColumnIndex < 0 Then Exit Sub

        ' SELECT USERNAME FROM COLUMN 1 OF ROW CLICKED
        SelectUser(dgvData.Item(1, e.RowIndex).Value)
    End Sub

    Private Sub msiDeleteUser_Click(sender As System.Object, e As System.EventArgs) Handles msiDeleteUser.Click
        DeleteUser()
    End Sub

    Private Sub msiUpdateUsers_Click(sender As System.Object, e As System.EventArgs) Handles msiUpdateUsers.Click
        UpdateUser.Show()
    End Sub

    Private Sub DynamicQueryToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles DynamicQueryToolStripMenuItem.Click
        DynamicQuery.Show()
    End Sub
End Class
