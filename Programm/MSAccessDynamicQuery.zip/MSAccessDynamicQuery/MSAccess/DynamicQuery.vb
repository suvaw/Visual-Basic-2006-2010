﻿Public Class DynamicQuery
    Private Access As New DBControl

    Private Sub LoadTables()
        ' PURGE & REFRESH TABLE LIST
        lbxTables.Items.Clear()
        Access.GetTables.ForEach(Sub(t) lbxTables.Items.Add(t))

        ' SELECT FIRST ITEM
        If lbxTables.Items.Count > 0 Then lbxTables.SelectedIndex = 0
    End Sub

    Private Sub LoadColumns()
        ' PURGE & REFRESH COLUMN LIST
        cbxColumn.Items.Clear()
        Access.GetColumnsByTable(lbxTables.Text).ForEach(Sub(c) cbxColumn.Items.Add(c))

        ' SELECT FIRST ITEM
        If cbxColumn.Items.Count > 0 Then cbxColumn.SelectedIndex = 0
    End Sub

    Private Sub QueryToGrid(FilterValue As String)
        ' ADD PARAMS & CREATE DYNAMIC QUERY
        Access.AddParam("@val", "%" & FilterValue & "%")
        Dim Query As String = String.Format("SELECT * FROM {0} WHERE {1} LIKE @val; ", lbxTables.Text, cbxColumn.Text)

        Access.ExecQuery(Query)

        ' ABORT ON ERRORS OR NO RECORDS
        If Not String.IsNullOrEmpty(Access.Exception) Then Exit Sub
        If Access.RecordCount < 1 Then Exit Sub

        ' REFRESH DATAGRID
        dgvDynamic.DataSource = Access.DBDT
    End Sub

    Private Sub CreateTable(TableName As String)
        Dim strCommand As String = String.Format("CREATE TABLE {0} " & _
                                                 "(ID AUTOINCREMENT, " & _
                                                 "Column2 CHAR, Column3 CHAR, " & _
                                                 "CONSTRAINT ID_PK PRIMARY KEY(ID)); ", TableName)
        Access.ExecQuery(strCommand)

        ' REPORT & ABORT ON ERRORS
        If Not String.IsNullOrEmpty(Access.Exception) Then MsgBox(Access.Exception) : Exit Sub

        ' ADD A TEST RECORD
        Access.ExecQuery(String.Format("INSERT INTO {0} (Column2,Column3) " & _
                                       "VALUES ('I love', 'VBTOOLBOX');", TableName))

        ' REPORT & ABORT ON ERRORS
        If Not String.IsNullOrEmpty(Access.Exception) Then MsgBox(Access.Exception)
    End Sub

    Private Sub DropTable(TableName)
        Access.ExecQuery(String.Format("DROP TABLE {0};", TableName))
        If Not String.IsNullOrEmpty(Access.Exception) Then MsgBox(Access.Exception)
    End Sub

    Private Sub DynamicQuery_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        LoadTables()
    End Sub

    Private Sub lbxTables_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lbxTables.SelectedIndexChanged
        LoadColumns()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
            e.SuppressKeyPress = True
            QueryToGrid(txtSearch.Text)
        End If
    End Sub

    Private Sub cmdCreate_Click(sender As System.Object, e As System.EventArgs) Handles cmdCreate.Click
        Dim Table As String = InputBox("Enter a table name:")
        If String.IsNullOrWhiteSpace(Table) Then Exit Sub

        CreateTable(Table)
        LoadTables()
    End Sub

    Private Sub cmdDelete_Click(sender As System.Object, e As System.EventArgs) Handles cmdDelete.Click
        Dim Table As String = InputBox("Enter a table name:")
        If String.IsNullOrWhiteSpace(Table) Then Exit Sub

        DropTable(Table)
        LoadTables()
    End Sub
End Class