﻿Public Class UpdateUser
    Private Access As New DBControl

    Private CurrentRecord As Integer = 0

    ' ERROR CHECKING & REPORTING 
    Private Function NoErrors(Optional Report As Boolean = False) As Boolean
        If Not String.IsNullOrEmpty(Access.Exception) Then
            If Report = True Then MsgBox(Access.Exception) ' REPORT ERRORS
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub GetUsers()
        ' QUERY USERS TO FILL DATA TABLE
        Access.ExecQuery("SELECT * FROM members")

        ' REPORT & ABORT ON ERRORS
        If NoErrors(True) = False OrElse Access.RecordCount < 1 Then Exit Sub

        ' GET FIRST RECORD
        GetRecord()
    End Sub

    Private Sub GetRecord()
        ' FAIL IF NO RECORDS FOUND OR POSITION IS OUT OF RANGE
        If Access.DBDT.Rows.Count < 1 OrElse CurrentRecord > Access.DBDT.Rows.Count - 1 Then Exit Sub

        ' RETRN FIRST USER FOUND
        Dim r As DataRow = Access.DBDT.Rows(CurrentRecord)

        ' POPULATE FIELDS
        txtUserID.Text = r("ID").ToString
        txtUser.Text = r("username").ToString
        txtPass.Text = r("password").ToString
        txtEmail.Text = r("email").ToString
        txtWebsite.Text = r("website").ToString

        If r("Active") IsNot Nothing Then cbActive.Checked = r("Active")
    End Sub

    Private Sub NextRecord(AddVal As Integer)
        CurrentRecord += AddVal ' Advance position by AddVal
        If CurrentRecord > Access.DBDT.Rows.Count - 1 Then CurrentRecord = 0 ' Loop to first record
        If CurrentRecord < 0 Then CurrentRecord = Access.DBDT.Rows.Count - 1 ' Loop to last record

        ' UPDATE FORM
        GetRecord()
    End Sub

    Private Sub UpdateRecord()
        ' FAIL IF NO USER SELECTED
        If String.IsNullOrEmpty(txtUserID.Text) Then Exit Sub

        ' ADD PARAMETERS - ORDER MATTERS !!!
        Access.AddParam("@user", txtUser.Text)
        Access.AddParam("@pass", txtPass.Text)
        Access.AddParam("@email", txtEmail.Text)
        Access.AddParam("@website", txtWebsite.Text)
        Access.AddParam("@active", cbActive.Checked)
        Access.AddParam("@uid", txtUserID.Text)

        ' RUN COMMAND
        Access.ExecQuery("UPDATE members " & _
                         "SET username=@user,[Password]=@pass,email=@email,website=@website,Active=@active " & _
                         "WHERE id=@uid")

        ' REPORT & ABORT ON ERRORS
        If NoErrors(True) = False Then Exit Sub

        ' REFRESH THE USERS DATATABLE & FETCH CURRENT RECORD
        GetUsers()
        Me.Text = Me.Text & " - " & "SAVED!"
    End Sub


    Private Sub UpdateUser_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        GetUsers()
    End Sub

    Private Sub cmdPrev_Click(sender As System.Object, e As System.EventArgs) Handles cmdPrev.Click
        NextRecord(-1)
    End Sub

    Private Sub cmdNext_Click(sender As System.Object, e As System.EventArgs) Handles cmdNext.Click
        NextRecord(1)
    End Sub

    Private Sub cmdFirst_Click(sender As System.Object, e As System.EventArgs) Handles cmdFirst.Click
        CurrentRecord = 0
        GetRecord()
    End Sub

    Private Sub cmdLast_Click(sender As System.Object, e As System.EventArgs) Handles cmdLast.Click
        CurrentRecord = Access.DBDT.Rows.Count - 1
        GetRecord()
    End Sub

    Private Sub cmdSave_Click(sender As System.Object, e As System.EventArgs) Handles cmdSave.Click
        UpdateRecord()
    End Sub
End Class