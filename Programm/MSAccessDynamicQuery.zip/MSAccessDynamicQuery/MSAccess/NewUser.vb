﻿Public Class NewUser
    Private Access As New DBControl

    Private Sub cmdCancel_Click(sender As System.Object, e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub TextBox_Validate(sender As System.Object, e As System.EventArgs) Handles txtUsername.TextChanged, txtPassword.TextChanged
        If Not String.IsNullOrWhiteSpace(txtUsername.Text) AndAlso Not String.IsNullOrWhiteSpace(txtPassword.Text) Then cmdSave.Enabled = True
    End Sub

    Private Sub AddUser()
        ' ADD PARAMETERS
        Access.AddParam("@user", txtUsername.Text)
        Access.AddParam("@pass", txtPassword.Text)
        Access.AddParam("@email", txtEmail.Text)
        Access.AddParam("@active", cbIsActive.Checked)

        ' EXECUTE INSERT COMMAND
        Access.ExecQuery("INSERT INTO members (username,[password],email,active) " & _
                         "VALUES (@user,@pass,@email,@active); ")

        ' REPORT & ABORT ON ERRORS
        If Not String.IsNullOrEmpty(Access.Exception) Then MsgBox(Access.Exception) : Exit Sub

        ' SUCCESS!!
        MsgBox("User was added successfully.")

        Form1.RefreshGrid()

        Me.Close()
    End Sub

    Private Sub cmdSave_Click(sender As System.Object, e As System.EventArgs) Handles cmdSave.Click
        AddUser()
    End Sub
End Class