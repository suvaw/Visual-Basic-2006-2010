﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DynamicQuery
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbxTables = New System.Windows.Forms.ListBox()
        Me.cbxColumn = New System.Windows.Forms.ComboBox()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvDynamic = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdCreate = New System.Windows.Forms.Button()
        Me.cmdDelete = New System.Windows.Forms.Button()
        CType(Me.dgvDynamic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbxTables
        '
        Me.lbxTables.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbxTables.FormattingEnabled = True
        Me.lbxTables.Location = New System.Drawing.Point(12, 7)
        Me.lbxTables.Name = "lbxTables"
        Me.lbxTables.Size = New System.Drawing.Size(126, 342)
        Me.lbxTables.TabIndex = 0
        '
        'cbxColumn
        '
        Me.cbxColumn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxColumn.FormattingEnabled = True
        Me.cbxColumn.Location = New System.Drawing.Point(9, 22)
        Me.cbxColumn.Name = "cbxColumn"
        Me.cbxColumn.Size = New System.Drawing.Size(152, 21)
        Me.cbxColumn.TabIndex = 1
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(10, 53)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(151, 20)
        Me.txtSearch.TabIndex = 2
        '
        'dgvDynamic
        '
        Me.dgvDynamic.AllowUserToAddRows = False
        Me.dgvDynamic.AllowUserToDeleteRows = False
        Me.dgvDynamic.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvDynamic.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDynamic.Location = New System.Drawing.Point(153, 105)
        Me.dgvDynamic.Name = "dgvDynamic"
        Me.dgvDynamic.ReadOnly = True
        Me.dgvDynamic.Size = New System.Drawing.Size(348, 246)
        Me.dgvDynamic.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cbxColumn)
        Me.GroupBox1.Controls.Add(Me.txtSearch)
        Me.GroupBox1.Location = New System.Drawing.Point(153, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(176, 87)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dynamic Search"
        '
        'cmdCreate
        '
        Me.cmdCreate.Location = New System.Drawing.Point(396, 12)
        Me.cmdCreate.Name = "cmdCreate"
        Me.cmdCreate.Size = New System.Drawing.Size(105, 24)
        Me.cmdCreate.TabIndex = 5
        Me.cmdCreate.Text = "Create Table"
        Me.cmdCreate.UseVisualStyleBackColor = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Location = New System.Drawing.Point(396, 42)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(105, 24)
        Me.cmdDelete.TabIndex = 6
        Me.cmdDelete.Text = "Delete Table"
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'DynamicQuery
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(513, 368)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCreate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgvDynamic)
        Me.Controls.Add(Me.lbxTables)
        Me.Name = "DynamicQuery"
        Me.Text = "DynamicQuery"
        CType(Me.dgvDynamic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbxTables As System.Windows.Forms.ListBox
    Friend WithEvents cbxColumn As System.Windows.Forms.ComboBox
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvDynamic As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdCreate As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
End Class
